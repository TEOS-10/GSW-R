library(oce);
cat("Some test cases; see Appendix of Gill's textbook...\n")
swRho(35, 13, 1000)
swSigma(35, 13, 1000)
swTheta(35, 13, 1000)
swSigmaT(35, 13, 1000)
swSigmaTheta(35, 13, 1000)
swSpice(35, 13, 1000)
