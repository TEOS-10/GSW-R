library(testthat)
library(oce)

test_check("oce")
