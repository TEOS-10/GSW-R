library(testthat)
# library(vprr)

testthat::test_check(package = "vprr")
