library(testthat)
library(vprr)

test_check("vprr")
